import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:kas_personsl/widgets/custom_icon_button.dart';
import 'package:kas_personsl/widgets/creator_info.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  void onKasMasukTap () => context.goNamed('kas_masuk');
  void as () => context.goNamed('kas_keluar');

  void onInfoTap() async {
    await showDialog(
      context: context, 
      builder: (context) {
        return const Dialog(
          child: CreatorInfo(),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kas Personal App'),
      ),
      body: Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Flexible(
                  fit: FlexFit.tight,
                  child: CustomIconButton(
                    backgroundColor: Color.fromARGB(184, 81, 255, 255),
                    icon: Icons.credit_card,
                    text: 'Kas Masuk',
                    onTap: onKasMasukTap,
                  ),
                ),
                const SizedBox(width: 20,),
                Flexible(
                  fit: FlexFit.tight,
                  child: CustomIconButton(
                    backgroundColor: Color.fromARGB(184, 81, 255, 255),
                    icon: Icons.receipt,
                    text: 'Kas Keluar',
                    onTap: as,
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            CustomIconButton(
              backgroundColor: Color.fromARGB(184, 81, 255, 255), 
              icon: Icons.info, 
              text: 'Tentang Pembuat', 
              onTap: onInfoTap,
            ),
          ],
        ),
      ),
    );
  }
}